const express =require("express");
const app = express();

require("dotenv").config();

const PORT = process.env.PORT || 3000;

app.use(express.json());

const users =require("./route/users");
app.use("api/v1",users);

const connect = require("./config/database");
connect();

app.listen(PORT ,() =>{
  console.log(`Server Started On ${PORT}`);
})

//default 
app.get("/", (req,res) =>{
  res.send(`<h1> This is My Homepage</h1>`);
})

